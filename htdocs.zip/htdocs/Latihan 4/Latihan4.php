<?php

  echo"hello world! <br>";
  echo"aku sayang kamu!";

?>