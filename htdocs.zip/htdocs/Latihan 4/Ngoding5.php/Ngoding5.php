<?php 
	$koneksi = new pdo('mysql:host=localhost;dbname=berita;','root','');

	if(!empty($_POST['simpan'])){
		$email = $_POST['email'];

		$hp = $_POST['hp'];

		$query = "insert into pelanggan(email, hp) values(?,?)";
		$save = $koneksi->prepare($query);
		$save->bindparam(1, $email);
		$save->bindparam(2, $hp);
		$save->execute();
	}

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Langanan Berita</title>
	<style>
		*{
			box-sizing: border-box;
		}
		h1{
			padding: 10px 20px;
			text-align: center;
		}
		.group{
			padding: 10px;
		}
		input{
			padding: 10px 20px;
			margin: 5px;
			width: 100%;
		}
		p{
			text-align: center;
		}
		input[type=submit]{
			border-radius: 14px;
			background-color: #285dab;
			color: #fff;
			border: none;
		}
	</style>
</head>
<body>
	<h1>FORM BERLANGGANAN BERITA</h1>
	<p>www.beritaterkini.com</p>
	<form method="post">
		<div class="group">
			<input type="email" name="email" placeholder="Email"> <br>
			<input type="text" name="hp" placeholder="Nomor HP" maxlength="13">
			<input type="submit" name="simpan" value="BERLANGGANAN SEKARANG!">
		</div>
	</form>
	############################# <br>
	<?php
		$queryTampil = "SELECT * FROM pelanggan";
		$tampil = $koneksi->prepare($queryTampil);
		$tampil->execute();
		foreach($tampil as $data){
			echo 'Data dari database yang ke'.$data['id_pelanggan'].$data['email'].$data['hp'].'<br>';
		}
	?>
</body>
</html>