var text = 120 + 1;
	function mouseover(){
		var x = document.querySelector('h1');
		x.innerHTML = text;
		x.style.backgroundColor = 'red';
		x.style.color = 'yellow';
}